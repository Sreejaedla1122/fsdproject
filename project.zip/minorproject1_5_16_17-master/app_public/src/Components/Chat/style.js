export const wrapperStyle = () => {

    return {
        width: "100vw",
        height: "100vh",
    }
}
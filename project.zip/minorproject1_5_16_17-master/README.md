# minorproject1_5_16_17
Fitness Tracker
#Instructions to run
1.npm install
2.npm start
3.search localhost:5000 on web browser
